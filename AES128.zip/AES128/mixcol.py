import numpy as np

def mix_columns(state):
    """
    Perform MixColumns operation on the given state.
    """
    # Define the Galois multiplication matrix
    mix_matrix = np.array([
        [2, 3, 1, 1],
        [1, 2, 3, 1],
        [1, 1, 2, 3],
        [3, 1, 1, 2]
    ])
    
    # Perform matrix multiplication
    result = np.zeros((4, 4), dtype=int)
    for i in range(4):
        for j in range(4):
            for k in range(4):
                result[i][j] ^= gf_mult(mix_matrix[i][k], state[k][j])
            result[i][j] %= 256  # Apply modulo to keep values within 0x00 to 0xFF
    
    return result

#Inverse Mix_Column Operation
def inv_mix_columns(state):
    """
    Perform Inverse MixColumns operation on the given state.
    """
    # Define the inverse Galois multiplication matrix
    inv_mix_matrix = np.array([
        [0x0e, 0x0b, 0x0d, 0x09],
        [0x09, 0x0e, 0x0b, 0x0d],
        [0x0d, 0x09, 0x0e, 0x0b],
        [0x0b, 0x0d, 0x09, 0x0e]
    ])

    # Perform matrix multiplication
    result = np.zeros((4, 4), dtype=int)
    for i in range(4):
        for j in range(4):
            for k in range(4):
                result[i][j] ^= gf_mult(inv_mix_matrix[i][k], state[k][j])
            result[i][j] %= 256  # Apply modulo to keep values within 0x00 to 0xFF

    return result


def gf_mult(a, b):
    """
    Perform Galois Field multiplication.
    """
    p = 0
    for _ in range(8):
        if b & 1:
            p ^= a
        hi_bit_set = a & 0x80
        a <<= 1
        if hi_bit_set:
            a ^= 0x1b  # Polynomial for AES
        b >>= 1
    return p

# Example usage:
state = np.array([
    [0xdb, 0x13, 0x53, 0x45],
    [0xf2, 0x0a, 0x22, 0x5c],
    [0x01, 0x01, 0x01, 0x01],
    [0xc6, 0xc6, 0xc6, 0xc6]
])
#Actual State
print("Actual State : ");
print(state)

mixed_state = mix_columns(state)
print("Mixed State:")
print(mixed_state)

#Output after Inverse Mix Column Operation
print("Output after Inverse_Mix_Column Operation: ") 
print(inv_mix_columns(mixed_state))

