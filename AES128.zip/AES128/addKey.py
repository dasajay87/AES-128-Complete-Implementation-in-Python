class AES:
    def __init__(self, state):
        self.state = state

    def add_round_key(self, round_key):
        """
        Add round key operation on the given state using the round key.
        """
        for i in range(4):
            for j in range(4):
                self.state[i][j] ^= round_key[i][j]  # XOR operation
        return self.state

# Example usage:
state = [
    [0x32, 0x88, 0x31, 0xe0],
    [0x43, 0x5a, 0x31, 0x37],
    [0xf6, 0x30, 0x98, 0x07],
    [0xa8, 0x8d, 0xa2, 0x34]
]

round_key = [
    [0x2b, 0x28, 0xab, 0x09],
    [0x7e, 0xae, 0xf7, 0xcf],
    [0x15, 0xd2, 0x15, 0x4f],
    [0x16, 0xa6, 0x88, 0x3c]
]

aes = AES(state)
print("State before adding round key:")
for row in aes.state:
    print(row)

aes.add_round_key(round_key)
print("\nState after adding round key:")
for row in aes.state:
    print(row)

#Inversing add_round_key

aes.add_round_key(round_key)
print("\nState after inversing round key:")
for row in aes.state:
    print(row)

