class AES:
    def __init__(self, state):
        self.state = state

    def shift_rows(self):
        """
        Perform ShiftRows operation on the given state.
        """
        for i in range(1, 4):  # Skip shifting the first row
            self.state[i] = self.state[i][i:] + self.state[i][:i]
        return self.state

    def inverse_shift_rows(self):
        """
        Perform inverse ShiftRows operation on the given state.
        """
        print(type(self.state))
        for i in range(1, 4):  # Skip shifting the first row
            print(self.state[i][-i:] + self.state[i][:-i])
            self.state[i] = self.state[i][-i:] + self.state[i][:-i]
        return self.state


# Example usage:
state = [
    [0x32, 0x88, 0x31, 0xe0],
    [0x43, 0x5a, 0x31, 0x37],
    [0xf6, 0x30, 0x98, 0x07],
    [0xa8, 0x8d, 0xa2, 0x34]
]

aes = AES(state)
print("State before ShiftRows:")
for row in aes.state:
    print(row)

aes.shift_rows()
print("\nState after ShiftRows:")
for row in aes.state:
    print(row)
print()
aes.inverse_shift_rows()
print("\nState after inverse ShiftRows:")
for row in aes.state:
    print(row)

